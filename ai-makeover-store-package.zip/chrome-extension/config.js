// Configuration for the AI Makeover Extension
window.AI_MAKEOVER_CONFIG = {
    API_BASE_URL: 'https://ai-makeover-153178030687.us-central1.run.app'
};

// For production, change to your deployed server URL:
// Example:
// const CONFIG = {
//     API_BASE_URL: 'https://your-production-domain.com'
// };
