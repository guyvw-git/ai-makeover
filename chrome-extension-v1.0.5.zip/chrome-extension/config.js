window.AI_MAKEOVER_CONFIG = {
    API_BASE_URL: 'https://ai-makeover-153178030687.us-central1.run.app'
    // API_BASE_URL: 'http://localhost:3000'
};

// For production, change to your deployed server URL:
// Example:
// const CONFIG = {
//     API_BASE_URL: 'https://your-production-domain.com'
// };
